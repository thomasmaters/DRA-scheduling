/*
 * main.cpp
 *
 *  Created on: 17 sep. 2015
 *      Author: thomas
 */
#include<iostream>
#include<vector>

#include "JobShop.hpp"
#include "Task.hpp"
#include "Job.hpp"
using namespace std;

unsigned long machine1 = 0;
unsigned long tijdsduur1 = 0;
unsigned long jobID1 = 0;
vector <Task> tasks1;

int main(int argc, char **argv) {
	JobShop j;
	return 0;
}




